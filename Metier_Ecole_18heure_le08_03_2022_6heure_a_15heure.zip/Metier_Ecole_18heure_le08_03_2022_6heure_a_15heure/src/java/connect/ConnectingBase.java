package connect;
import java.sql.*;
public class ConnectingBase{
	private String port = "1521";
	private Connection con ;
	private String url;
	private String baseForname;
	/// Postgres = "org.postgresql.Driver";
	/// ORACLE = "oracle.jdbc.driver.OracleDriver";
	/// URL POSTGRESS = "jdbc:postgresql://localhost:1532/DATABASE";
	public ConnectingBase(String base,String ur){
		baseForname = base;
		url = ur;
	}
	//private  Statement stmt;
	public void setUrl(String ur){
		url = ur;
	}
	private String getUrl(){
		//String url = "jdbc:oracle:thin:@localhost:1521:ORCL";
		return url;
	}
	public void connectingOracle(String username,String password) throws Exception{
      				con = DriverManager.getConnection(getUrl(),username,password);
					 con.setAutoCommit(true);
	}
	public  Connection getConnectionOracle(){
		return con;
	}
	public void validCommit()throws Exception{
		con.commit();
	}
	public void deleteRollback()throws Exception{
		con.rollback();
	}
}