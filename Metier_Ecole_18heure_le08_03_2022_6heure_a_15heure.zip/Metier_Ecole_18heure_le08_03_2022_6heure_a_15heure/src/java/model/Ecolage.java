package model;
import connect.*;
import java.sql.*;
import java.io.*;
import java.util.*;
import fonction.*;
public class Ecolage{

    public String[][] liste_Ecolage_Par_Niveau(){
         Connection con = PostSingleton.getConnection();
          Selection sel = new Selection(con);
          return sel.selectionTable("select Nom_classe,Ecolage from Classe");
    }
}